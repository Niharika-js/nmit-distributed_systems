
#include "four.h"

int *
four_1_svc(s *argp, struct svc_req *rqstp)
{
	static int  result;
             result=((argp->a)%4);
           
            printf("4 MODULO IS %d",result);
            

	return &result;
}
