
#include "four.h"

bool_t
xdr_s (XDR *xdrs, s *objp)
{
	register int32_t *buf;

	 if (!xdr_int (xdrs, &objp->a))
		 return FALSE;
	return TRUE;
}
